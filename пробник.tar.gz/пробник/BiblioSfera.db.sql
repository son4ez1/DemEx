BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "Book_type" (
	"ID"	INTEGER,
	"Type"	TEXT,
	"Kooeficent"	REAL,
	PRIMARY KEY("ID")
);
CREATE TABLE IF NOT EXISTS "Books" (
	"Artikyl"	INTEGER,
	"id_type_book"	INTEGER,
	"Naimenovanie"	TEXT,
	"Min_cost_vidachi"	REAL,
	PRIMARY KEY("Artikyl"),
	FOREIGN KEY("id_type_book") REFERENCES "Book_type"("ID")
);
CREATE TABLE IF NOT EXISTS "Material_type" (
	"ID"	INTEGER,
	"Type"	TEXT,
	"Procent_braka_materiala"	REAL,
	PRIMARY KEY("ID")
);
CREATE TABLE IF NOT EXISTS "Partner_books" (
	"id_partnera"	INTEGER,
	"Artikyl_book"	INTEGER,
	"Kolichestvo"	INTEGER,
	"Date_vidachi"	TEXT,
	FOREIGN KEY("id_partnera") REFERENCES "Partners"("INN"),
	FOREIGN KEY("Artikyl_book") REFERENCES "Books"("Artikyl")
);
CREATE TABLE IF NOT EXISTS "Partner_type" (
	"ID"	INTEGER,
	"Type"	TEXT,
	PRIMARY KEY("ID")
);
CREATE TABLE IF NOT EXISTS "Partners" (
	"INN"	INTEGER,
	"Naimenovanie"	TEXT,
	"id_type_partnera"	INTEGER,
	"Reiting"	INTEGER,
	"Adress_Index"	INTEGER,
	"Oblast"	TEXT,
	"Gorod"	TEXT,
	"Ylica"	TEXT,
	"Dom"	TEXT,
	"Familiya_directora"	TEXT,
	"Name_directora"	TEXT,
	"Otchestvo_directora"	TEXT,
	"Phone"	TEXT,
	"Email"	TEXT,
	PRIMARY KEY("INN"),
	FOREIGN KEY("id_type_partnera") REFERENCES "Partner_type"("ID")
);
INSERT INTO "Book_type" ("ID","Type","Kooeficent") VALUES (1,'Художественная',1.5),
 (2,'Научная',2.25),
 (3,'Детская',1.0),
 (4,'Учебник',2.0),
 (5,'Справочник',1.75);
INSERT INTO "Books" ("Artikyl","id_type_book","Naimenovanie","Min_cost_vidachi") VALUES (5012543,5,'Энциклопедия животных',175.0),
 (7028748,4,'Математический анализ',250.75),
 (7750282,3,'Сказки на ночь',100.25),
 (8758385,1,'Война и мир',150.0),
 (8858958,2,'Квантовая физика для начинающих',300.5);
INSERT INTO "Material_type" ("ID","Type","Procent_braka_materiala") VALUES (1,'Бумага офсетная',0.1),
 (2,'Картон',0.95),
 (3,'Переплетный материал',0.28),
 (4,'Обложка',0.55),
 (5,'Ламинат',0.34);
INSERT INTO "Partner_books" ("id_partnera","Artikyl_book","Kolichestvo","Date_vidachi") VALUES (2222455179,8758385,150,'23.03.23'),
 (3333888520,7750282,123,'18.12.23'),
 (4440391035,8858958,374,'07.06.24'),
 (4440391035,7028748,125,'17.05.23'),
 (1111520857,5012543,755,'01.07.24');
INSERT INTO "Partner_type" ("ID","Type") VALUES (1,'ЗАО'),
 (2,'ООО'),
 (3,'ПАО'),
 (4,'ОАО');
INSERT INTO "Partners" ("INN","Naimenovanie","id_type_partnera","Reiting","Adress_Index","Oblast","Gorod","Ylica","Dom","Familiya_directora","Name_directora","Otchestvo_directora","Phone","Email") VALUES (1111520857,'Библиотека №10',4,5,143960,'Московская область','город Реутов','ул. Свободы','51','Воробьева','Екатерина','Валерьевна','+7 444 222 33 11','ekaterina.vorobeva@ml.ru'),
 (2222455179,'Школа №1',1,7,652050,'Кемеровская область','город Юрга','ул. Лесная','15','Иванова','Александра','Ивановна','+7 493 123 45 67','aleksandraivanova@ml.ru'),
 (3333888520,'Детский сад №5',2,7,164500,'Архангельская область','город Северодвинск','ул. Строителей','18','Петров','Василий','Петрович','+7 987 123 56 78','vppetrov@vl.ru'),
 (4440391035,'Университет №3',3,7,188910,'Ленинградская область','город Приморск','ул. Парковая','21','Соловьев','Андрей','Николаевич','+7 812 223 32 00','ansolovev@st.ru'),
 (123456789876,'dfbhgfnh',2,5,123456,'tdhbgf','nghf','nh','nhg','nhg','nh','nhn','+7 848 586 45 67','edfre@main.py'),
 (333388852011,'Детский сад №5',3,7,164500,'Архангельская область','город Северодвинск','ул. Строителей','18','Петров','Василий','Петрович','+7 987 123 56 78','vppetrov@vl.ru'),
 (777777777777,'7',2,1,777777,'7','7','7','7','7','7','7','+7 777 777 77 77','87@hh.c'),
 (888888888888,'8',1,8,888888,'8','8','8','8','8','8','8','+7 888 888 88 88','88@g.com');
COMMIT;
